package com.techelevator.cocktail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CocktailApplicationTests {

	@Test
	void contextLoads() {
	}

}
